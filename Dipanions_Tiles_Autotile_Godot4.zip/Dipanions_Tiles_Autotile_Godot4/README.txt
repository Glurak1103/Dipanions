Dipanions – Autotile Build (Godot 4)

• Übergänge: Kanten & Ecken für Weg->Gras und Pflaster->Gras sind als separate Tiles im Atlas angelegt und werden automatisch gesetzt.
• world.tscn: öffne und starte zum Testen.
• HTML5 Export: preset liegt bei (export_presets.cfg). In Godot: Project → Export → HTML5 → Export Project. (Export-Templates müssen installiert sein).

Tipp: Du kannst weitere Bereiche im Script `scripts/world.gd` mit `_blend_edges()` hinzufügen.